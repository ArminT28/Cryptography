javac ElGamal.java
java ElGamal
